import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.io.IOException;

 
import javax.imageio.ImageIO;

public class ImageFile 
{
    BufferedImage outImage;
    public static byte[] writeImageToBytes () throws IOException
    {
        int width = 680;
        int height = 610;
        int rgb = new Color(0,191,255).getRGB();
        int rgb3 = new Color(0,177,0).getRGB();
        int rgb2 = new Color(0,123,0).getRGB();
        // Constructs a BufferedImage of one of the predefined image types.
        BufferedImage canvas = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        // Create a graphics which can be used to draw into the buffered image
        Graphics2D g2d = canvas.createGraphics();
        // fill all the image with white
        for (int i=0; i<canvas.getWidth(); i++)
        {
            for (int j=0; j<canvas.getHeight(); j++)
            {
                for (int x=0; x<golfField.database.length; x++)
                { 
                    if (x<0 )
                    {
                        canvas.setRGB(i, j, rgb);
                    }
                    else if (x>0 && x<50)
                    {
                        canvas.setRGB(i, j, rgb2);
                    }
                    else if (x>50)
                    {
                        canvas.setRGB(i, j, rgb3);
                    }
                }
            }
        }
        // Save as PNG
        ImageIO.write(canvas, "png", baos);
        return baos.toByteArray();
    }

    public static void setup() throws IOException
    {
        byte[] bytearray = writeImageToBytes ();


    }





    // public static String recorder() throws IOException
    // {
    //     writeImageToBytes ();
    //     File file = new File("")
    //     return "";
    // }
}
