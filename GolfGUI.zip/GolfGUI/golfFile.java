import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.io.IOException;
 
import javax.imageio.ImageIO;
 
public class golfFile 
{
 
    public static File file;
    public static void main(String[] args) throws IOException 
    {
 
    }

    public static byte[] writeImageToBytes (ImageFile image) throws IOException
    {
        int width = 680;
        int height = 610;
        int rgb = new Color(0,191,255).getRGB();
        int rgb3 = new Color(0,177,0).getRGB();
        int rgb2 = new Color(0,123,0).getRGB();
        // Constructs a BufferedImage of one of the predefined image types.
        BufferedImage canvas = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
 
        // Create a graphics which can be used to draw into the buffered image
        Graphics2D g2d = canvas.createGraphics();
        // fill all the image with white
        for (int i=0; i<canvas.getWidth(); i++)
        {
            for (int j=0; j<canvas.getHeight(); j++)
            {
                for (int x=0; x<golfField.database.length; x++)
                { 
                    if (x<0 )
                    {
                        canvas.setRGB(i, j, rgb);
                    }
                    else if (x>0 && x<50)
                    {
                        canvas.setRGB(i, j, rgb2);
                    }
                    else if (x>50)
                    {
                        canvas.setRGB(i, j, rgb3);
                    }
                }
            }
        }
        // Save as PNG
        file = new File("/Users/vantsevvictor/Downloads/Project 1-2/Golf/res/field.png");
        //ImageIO.write(canvas, "png", file);
    }
 }